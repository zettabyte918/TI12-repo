#include <stdio.h>

int position(int x,int t[]){

}

void main(){
    int nb,i,x;
    int t[50];
    printf("entrez un entier: ");
    scanf("%d",&nb);
    for(i=0;i<10;i++){
        printf("entre un valeur N°%d= ",i);
        scanf("%d",&t[i]);
    }
    x=
    do{

    }while();
}