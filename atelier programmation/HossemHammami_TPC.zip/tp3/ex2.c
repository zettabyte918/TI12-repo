#include <stdio.h>
void main(){
    char c;

    while (c !='N')
    {
        printf("Voulez vous Continuez ? ");
        scanf("%c",&c);
    }
    
    
}